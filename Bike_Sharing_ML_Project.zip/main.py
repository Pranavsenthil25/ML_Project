python main.py --model linear
python main.py --model nn
